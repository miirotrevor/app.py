## Banking system : Object oriented programming example
A minimal application to understand oops concept with python

It is part of the online udemy course named "The Four Pillars of OOP in Python 3 for Beginners"
